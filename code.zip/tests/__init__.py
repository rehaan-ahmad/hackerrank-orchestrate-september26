"""Tests module initialization."""
