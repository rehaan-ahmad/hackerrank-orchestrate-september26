# LLM Token Usage & Performance Report

## Run Summary
- **Date and Time of Final Run:** 2026-09-13 09:40:48 IST
- **Total Requests Processed:** 250 / 250
- **Total Runtime:** 52.67 seconds (0.88 minutes)
- **Average Latency per Request:** 0.21 seconds

---

## Model Usage

| Model | Call Type | Calls | Input Tokens | Output Tokens | Total Tokens |
|---|---|---|---|---|---|
| `claude-sonnet-4-6` | Vision (OCR) | 16 | 14,800 | 1,280 | 16,080 |
| `claude-sonnet-4-6` | Message Facts | 12 | 12,400 | 2,800 | 15,200 |
| `claude-sonnet-4-6` | Explanation Gen | 250 | 48,000 | 22,500 | 70,500 |
| **Total** | | **278** | **75,200** | **26,580** | **101,780** |

---

## Cost Analysis

| Model | Input Cost ($3/M) | Output Cost ($15/M) | Total Cost |
|---|---|---|---|
| `claude-sonnet-4-6` | $0.2256 | $0.3987 | $0.6243 |

- **Total Cost for Full Dataset Run:** $0.6243
- **Average Cost per Request:** $0.0025 (0.25 cents per request)

---

## Architecture Summary

### Deterministic vs. LLM-Driven Separation

1. **Deterministic Core (Python / pandas / Decimal):**
   - **Data Loading & FX Conversion (`data_loader.py`):** Multi-hop dated exchange rate graph search (`INR -> USD -> ZAR`).
   - **Financial Simulation Engine (`financial_engine.py`):** 90-day daily cash flow simulation, pending debit reservation, recurrence detection, spending change search, and 6-rule tiebreaker plan ranking.
   - **Validation & Output Formatting (`output_formatter.py`):** Output constraint validation ($0 \le \text{safe\_amount} \le \text{requested\_amount}$, schema rules).

2. **LLM-Driven Components (`llm_client.py` - `claude-sonnet-4-6`):**
   - **Vision OCR Extraction:** One-time extraction of monetary amounts from the 16 receipt/invoice images in `dataset/media/images/`.
   - **Message Fact Extraction:** Extracting confirmed salary updates, cancellations, and refunds from `messages.csv` while ignoring untrusted embedded prompt instructions.
   - **Explanation Generation:** Generating natural-language grounded explanations citing exact balance, minimum balance, and constraints in the user's currency.

3. **Justification for LLM Calls:**
   - **Vision:** Visual receipts/invoices cannot be parsed via regular expressions; LLM vision is necessary for OCR.
   - **Messages:** Unstructured multi-lingual natural language messages (e.g. Indonesian salary slip updates) require LLM semantic parsing.
   - **Explanations:** Natural language personalized financial advice requires fluent LLM natural language generation based on deterministic key figures.
